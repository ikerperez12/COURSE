using FruitStore.Controllers;
using FruitStore.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Xunit;
namespace FruitStore.Tests.Controllers
{
    public class FruitControllerTests
    {
        private static FruitContext CreateContext()
        {
            var options = new DbContextOptionsBuilder<FruitContext>().UseInMemoryDatabase(Guid.NewGuid().ToString()).Options;
            var context = new FruitContext(options);
            context.Database.EnsureCreated();
            return context;
        }

        [Fact]
        public async Task GetFruits_ReturnsAllFruits()
        {
            using var context = CreateContext();
            var result = await new FruitController(context).GetFruits();
            var fruits = Assert.IsAssignableFrom<IEnumerable<Fruit>>(result.Value);
            Assert.Equal(13, fruits.Count());
        }

        [Fact]
        public async Task GetFruit_WithValidId_ReturnsFruit()
        {
            using var context = CreateContext();
            var result = await new FruitController(context).GetFruit(1);
            var ok = Assert.IsType<OkObjectResult>(result);
            Assert.Equal("Apple", Assert.IsType<Fruit>(ok.Value).Name);
        }

        [Fact]
        public async Task GetFruit_WithInvalidId_ReturnsExpectedMessage()
        {
            using var context = CreateContext();
            var result = await new FruitController(context).GetFruit(99);
            Assert.Equal("No fruit with this id", Assert.IsType<NotFoundObjectResult>(result).Value);
        }

        [Fact]
        public async Task PostFruit_AddsFruit()
        {
            using var context = CreateContext();
            var controller = new FruitController(context);
            var fruit = new Fruit { Id=14, Name="Cherry", Description="A small sweet red fruit.", Price=2.49, Instock=true, Origin="Spain" };
            var result = await controller.PostFruit(fruit);
            Assert.IsType<CreatedAtActionResult>(result.Result);
            Assert.True(await context.Fruits.AnyAsync(f => f.Id == 14));
        }

        [Fact]
        public async Task PutFruit_WithValidId_UpdatesFruit()
        {
            using var context = CreateContext();
            var controller = new FruitController(context);
            var fruit = await context.Fruits.AsNoTracking().SingleAsync(f => f.Id == 1);
            fruit.Name = "Updated Apple";
            Assert.IsType<NoContentResult>(await controller.PutFruit(1, fruit));
            Assert.Equal("Updated Apple", (await context.Fruits.AsNoTracking().SingleAsync(f => f.Id == 1)).Name);
        }

        [Fact]
        public async Task PutFruit_WithDifferentId_ReturnsBadRequest()
        {
            using var context = CreateContext();
            Assert.IsType<BadRequestResult>(await new FruitController(context).PutFruit(2, new Fruit { Id=1, Name="Apple" }));
        }

        [Fact]
        public async Task DeleteFruit_WithValidId_RemovesFruit()
        {
            using var context = CreateContext();
            var controller = new FruitController(context);
            Assert.IsType<NoContentResult>(await controller.DeleteFruit(1));
            Assert.False(await context.Fruits.AnyAsync(f => f.Id == 1));
        }

        [Fact]
        public async Task DeleteFruit_WithInvalidId_ReturnsNotFound()
        {
            using var context = CreateContext();
            Assert.IsType<NotFoundResult>(await new FruitController(context).DeleteFruit(99));
        }
    }
}
