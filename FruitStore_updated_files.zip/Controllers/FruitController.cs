using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using FruitStore.Models;
namespace FruitStore.Controllers
{
    /// <summary>Provides API operations to retrieve, add, update, and delete FruitStore fruits.</summary>
    [ApiController]
    [Route("api/[controller]")]
    public class FruitController : ControllerBase
    {
        private readonly FruitContext _context;
        public FruitController(FruitContext context) { _context = context; }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Fruit>>> GetFruits() => await _context.Fruits.ToListAsync();

        [HttpGet("{id}")]
        public async Task<IActionResult> GetFruit(int id)
        {
            var fruit = await _context.Fruits.FindAsync(id);
            return fruit == null ? NotFound("No fruit with this id") : Ok(fruit);
        }

        [HttpPost]
        public async Task<ActionResult<Fruit>> PostFruit(Fruit fruit)
        {
            _context.Fruits.Add(fruit);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(GetFruit), new { id = fruit.Id }, fruit);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutFruit(int id, Fruit fruit)
        {
            if (id != fruit.Id) return BadRequest();
            _context.Entry(fruit).State = EntityState.Modified;
            try { await _context.SaveChangesAsync(); }
            catch (DbUpdateConcurrencyException)
            {
                if (!FruitExists(id)) return NotFound();
                throw;
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFruit(int id)
        {
            var fruit = await _context.Fruits.FindAsync(id);
            if (fruit == null) return NotFound();
            _context.Fruits.Remove(fruit);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        private bool FruitExists(int id) => _context.Fruits.Any(e => e.Id == id);
    }
}
