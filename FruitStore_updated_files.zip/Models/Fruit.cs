using System.Text.Json.Serialization;
namespace FruitStore.Models;
/// <summary>Represents a fruit available in the FruitStore.</summary>
public class Fruit
{
    /// <summary>Gets or sets the unique identifier.</summary>
    [JsonPropertyName("id")] public int Id { get; set; }
    /// <summary>Gets or sets the fruit name.</summary>
    [JsonPropertyName("name")] public string? Name { get; set; }
    /// <summary>Gets or sets the description.</summary>
    [JsonPropertyName("description")] public string? Description { get; set; }
    /// <summary>Gets or sets the price.</summary>
    [JsonPropertyName("price")] public double? Price { get; set; }
    /// <summary>Gets or sets whether the fruit is in stock.</summary>
    [JsonPropertyName("instock")] public bool? Instock { get; set; }
    /// <summary>Gets or sets the origin.</summary>
    [JsonPropertyName("origin")] public string? Origin { get; set; }
}
