using FruitStore.Models;
using Microsoft.EntityFrameworkCore;

public class FruitContext(DbContextOptions<FruitContext> options) : DbContext(options)
{
    public virtual DbSet<Fruit> Fruits { get; set; } = null!;
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<Fruit>().HasData(
            new Fruit { Id=1, Name="Apple", Description="A delicious fruit. It's good for you!", Instock=true, Price=0.99, Origin="Belgium" },
            new Fruit { Id=2, Name="Banana", Description="A yellow fruit. It's good for you!", Instock=false, Price=0.99, Origin="Africa" },
            new Fruit { Id=3, Name="Orange", Description="A round fruit. It's good for you!", Instock=true, Price=0.99, Origin="Spain" },
            new Fruit { Id=4, Name="Pear", Description="A sweet and juicy fruit. It's good for you!", Instock=true, Price=1.29, Origin="France" },
            new Fruit { Id=5, Name="Strawberry", Description="A sweet red fruit. It's good for you!", Instock=true, Price=2.49, Origin="Spain" },
            new Fruit { Id=6, Name="Grapes", Description="Small sweet and juicy fruits. They're good for you!", Instock=true, Price=2.99, Origin="Italy" },
            new Fruit { Id=7, Name="Pineapple", Description="A tropical fruit. It's good for you!", Instock=true, Price=3.49, Origin="Costa Rica" },
            new Fruit { Id=8, Name="Mango", Description="A sweet tropical fruit. It's good for you!", Instock=true, Price=2.19, Origin="India" },
            new Fruit { Id=9, Name="Blueberry", Description="A small blue fruit. It's good for you!", Instock=true, Price=3.29, Origin="Canada" },
            new Fruit { Id=10, Name="Watermelon", Description="A refreshing juicy fruit. It's good for you!", Instock=true, Price=4.99, Origin="Spain" },
            new Fruit { Id=11, Name="Kiwi", Description="A tangy green fruit. It's good for you!", Instock=true, Price=1.19, Origin="New Zealand" },
            new Fruit { Id=12, Name="Peach", Description="A soft and juicy fruit. It's good for you!", Instock=true, Price=1.49, Origin="Spain" },
            new Fruit { Id=13, Name="Plum", Description="A sweet purple fruit. It's good for you!", Instock=true, Price=1.39, Origin="France" }
        );
    }
}
